export interface CalculationRecord {
  id: number;
  date: string;
  inputs: {
    tonPrice: number;
    fabricWidth: number;
    gramWeight: number;
    transportCost: number;
    exchangeRate: number;
    bagLength?: number;
  };
  results: {
    meterWeight: number;
    metersInTon: number;
    meterPrice: number;
    totalCost: number;
    meterPriceIQD: number;
    totalCostIQD: number;
  };
  bagsResult?: {
    bagWeight: number;
    bagsInTon: number;
    bagsPrice: number;
    bagsPriceIQD: number;
  };
}