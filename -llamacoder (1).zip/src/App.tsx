import { useState } from "react";
import FabricCalculator from "./components/FabricCalculator";
import CalculationHistory from "./components/CalculationHistory";
import { CalculationRecord } from "./types/calculator";

function App() {
  const [history, setHistory] = useState<CalculationRecord[]>([]);

  const addToHistory = (record: CalculationRecord) => {
    setHistory((prev) => [record, ...prev].slice(0, 20));
  };

  const clearHistory = () => {
    setHistory([]);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 to-slate-800">
      <div className="max-w-md mx-auto px-4 py-6 pb-20">
        <header className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-3xl mb-4 shadow-lg shadow-emerald-500/30">
            <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
            </svg>
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">حاسبة الأمارة</h1>
          <p className="text-slate-400 text-sm">حساب سعر المتر للقماش المنسوج</p>
          <div className="flex items-center justify-center gap-2 mt-2">
            <span className="px-3 py-1 bg-emerald-500/20 text-emerald-400 text-xs rounded-full">الإصدار 2.0</span>
          </div>
        </header>

        <FabricCalculator onCalculate={addToHistory} />
        
        {history.length > 0 && (
          <CalculationHistory history={history} onClear={clearHistory} />
        )}
        
        <footer className="mt-8 text-center">
          <p className="text-slate-600 text-xs">© 2024 حاسبة الأمارة - جميع الحقوق محفوظة</p>
        </footer>
      </div>
    </div>
  );
}

export default App;