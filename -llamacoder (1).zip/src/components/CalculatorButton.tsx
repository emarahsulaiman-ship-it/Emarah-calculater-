import { useState } from "react";

interface CalculatorButtonProps {
  label: string;
  onClick: () => void;
  type: "number" | "operator" | "function" | "equals";
}

const CalculatorButton = ({ label, onClick, type }: CalculatorButtonProps) => {
  const [isPressed, setIsPressed] = useState(false);

  const baseStyles = "h-16 rounded-2xl text-2xl font-medium transition-all duration-150 active:scale-95 flex items-center justify-center";
  
  const typeStyles = {
    number: "bg-slate-700 text-white hover:bg-slate-600 active:bg-slate-500",
    operator: "bg-amber-500 text-white hover:bg-amber-400 active:bg-amber-300",
    function: "bg-slate-600 text-amber-400 hover:bg-slate-500 active:bg-slate-400",
    equals: "bg-emerald-500 text-white hover:bg-emerald-400 active:bg-emerald-300",
  };

  const handleMouseDown = () => setIsPressed(true);
  const handleMouseUp = () => setIsPressed(false);

  return (
    <button
      className={`${baseStyles} ${typeStyles[type]} ${isPressed ? "scale-95" : ""}`}
      onClick={onClick}
      onMouseDown={handleMouseDown}
      onMouseUp={handleMouseUp}
      onMouseLeave={() => setIsPressed(false)}
    >
      {label}
    </button>
  );
};

export default CalculatorButton;