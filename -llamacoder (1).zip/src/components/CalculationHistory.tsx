import { CalculationRecord } from "../types/calculator";

interface CalculationHistoryProps {
  history: CalculationRecord[];
  onClear: () => void;
}

const CalculationHistory = ({ history, onClear }: CalculationHistoryProps) => {
  return (
    <div className="mt-6 bg-slate-800/50 rounded-3xl p-4 border border-slate-700/30">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-medium text-slate-300">سجل الحسابات</h3>
        <button
          onClick={onClear}
          className="text-xs text-slate-500 hover:text-rose-400 transition-colors"
        >
          مسح السجل
        </button>
      </div>
      <div className="space-y-2 max-h-60 overflow-y-auto">
        {history.map((record) => (
          <div
            key={record.id}
            className="bg-slate-700/30 rounded-xl p-3 text-xs"
          >
            <div className="flex justify-between items-center mb-2">
              <span className="text-slate-500">{record.date}</span>
              <div className="flex gap-3">
                <span className="text-emerald-400 font-semibold">
                  ${record.results.meterPrice.toFixed(2)}/متر
                </span>
                {record.inputs.exchangeRate > 0 && (
                  <span className="text-violet-400 font-semibold">
                    {record.results.meterPriceIQD.toLocaleString('en-US')} د.ع
                  </span>
                )}
              </div>
            </div>
            <div className="flex flex-wrap gap-2 text-slate-400">
              <span>الطن: ${record.inputs.tonPrice}</span>
              <span>•</span>
              <span>العرض: {record.inputs.fabricWidth}سم</span>
              <span>•</span>
              <span>الوزن: {record.inputs.gramWeight}غ</span>
              {record.inputs.bagLength && record.inputs.bagLength > 0 && (
                <>
                  <span>•</span>
                  <span className="text-cyan-400">طول الكيس: {record.inputs.bagLength}م</span>
                </>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CalculationHistory;