interface CalculatorDisplayProps {
  value: string;
  expression: string;
}

const CalculatorDisplay = ({ value, expression }: CalculatorDisplayProps) => {
  const formatDisplay = (num: string) => {
    const number = parseFloat(num);
    if (isNaN(number)) return "0";
    if (num.includes(".")) {
      const parts = num.split(".");
      return `${parseFloat(parts[0]).toLocaleString("en-US")}.${parts[1]}`;
    }
    return number.toLocaleString("en-US");
  };

  return (
    <div className="bg-slate-900 rounded-2xl p-6 mb-4 min-h-32 flex flex-col justify-end">
      <div className="text-slate-500 text-right text-sm h-6 mb-1 font-mono">
        {expression}
      </div>
      <div className="text-white text-right text-5xl font-light tracking-tight overflow-hidden font-mono">
        {formatDisplay(value)}
      </div>
    </div>
  );
};

export default CalculatorDisplay;