import { useState, useEffect } from "react";
import CalculatorDisplay from "./CalculatorDisplay";
import CalculatorButton from "./CalculatorButton";
import { formatNumber, calculate } from "../utils/calculator";

interface CalculatorProps {
  onCalculate: (expression: string, result: string) => void;
}

const Calculator = ({ onCalculate }: CalculatorProps) => {
  const [display, setDisplay] = useState("0");
  const [previousValue, setPreviousValue] = useState<string | null>(null);
  const [operator, setOperator] = useState<string | null>(null);
  const [waitingForOperand, setWaitingForOperand] = useState(false);
  const [expression, setExpression] = useState("");

  const handleNumber = (num: string) => {
    if (waitingForOperand) {
      setDisplay(num);
      setWaitingForOperand(false);
    } else {
      setDisplay(display === "0" ? num : display + num);
    }
  };

  const handleDecimal = () => {
    if (waitingForOperand) {
      setDisplay("0.");
      setWaitingForOperand(false);
    } else if (!display.includes(".")) {
      setDisplay(display + ".");
    }
  };

  const handleOperator = (nextOperator: string) => {
    const inputValue = parseFloat(display);

    if (previousValue === null) {
      setPreviousValue(display);
      setExpression(display + " " + nextOperator);
    } else if (operator) {
      const result = calculate(parseFloat(previousValue), inputValue, operator);
      setDisplay(String(result));
      setPreviousValue(String(result));
      setExpression(result + " " + nextOperator);
    }

    setOperator(nextOperator);
    setWaitingForOperand(true);
  };

  const handleEquals = () => {
    if (operator && previousValue !== null) {
      const inputValue = parseFloat(display);
      const result = calculate(parseFloat(previousValue), inputValue, operator);
      const fullExpression = `${previousValue} ${operator} ${display}`;
      
      setDisplay(String(result));
      onCalculate(fullExpression, formatNumber(result));
      
      setPreviousValue(null);
      setOperator(null);
      setWaitingForOperand(true);
      setExpression("");
    }
  };

  const handleClear = () => {
    setDisplay("0");
    setPreviousValue(null);
    setOperator(null);
    setWaitingForOperand(false);
    setExpression("");
  };

  const handleBackspace = () => {
    if (display.length > 1) {
      setDisplay(display.slice(0, -1));
    } else {
      setDisplay("0");
    }
  };

  const handlePercentage = () => {
    const value = parseFloat(display);
    setDisplay(String(value / 100));
  };

  const handlePlusMinus = () => {
    const value = parseFloat(display);
    setDisplay(String(value * -1));
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key >= "0" && e.key <= "9") handleNumber(e.key);
      else if (e.key === ".") handleDecimal();
      else if (e.key === "+") handleOperator("+");
      else if (e.key === "-") handleOperator("-");
      else if (e.key === "*") handleOperator("×");
      else if (e.key === "/") handleOperator("÷");
      else if (e.key === "Enter" || e.key === "=") handleEquals();
      else if (e.key === "Escape") handleClear();
      else if (e.key === "Backspace") handleBackspace();
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  });

  const buttons = [
    { label: "C", action: handleClear, type: "function" as const },
    { label: "±", action: handlePlusMinus, type: "function" as const },
    { label: "%", action: handlePercentage, type: "function" as const },
    { label: "÷", action: () => handleOperator("÷"), type: "operator" as const },
    { label: "7", action: () => handleNumber("7"), type: "number" as const },
    { label: "8", action: () => handleNumber("8"), type: "number" as const },
    { label: "9", action: () => handleNumber("9"), type: "number" as const },
    { label: "×", action: () => handleOperator("×"), type: "operator" as const },
    { label: "4", action: () => handleNumber("4"), type: "number" as const },
    { label: "5", action: () => handleNumber("5"), type: "number" as const },
    { label: "6", action: () => handleNumber("6"), type: "number" as const },
    { label: "-", action: () => handleOperator("-"), type: "operator" as const },
    { label: "1", action: () => handleNumber("1"), type: "number" as const },
    { label: "2", action: () => handleNumber("2"), type: "number" as const },
    { label: "3", action: () => handleNumber("3"), type: "number" as const },
    { label: "+", action: () => handleOperator("+"), type: "operator" as const },
    { label: "⌫", action: handleBackspace, type: "function" as const },
    { label: "0", action: () => handleNumber("0"), type: "number" as const },
    { label: ".", action: handleDecimal, type: "number" as const },
    { label: "=", action: handleEquals, type: "equals" as const },
  ];

  return (
    <div className="bg-slate-800 rounded-3xl p-4 shadow-2xl">
      <CalculatorDisplay value={display} expression={expression} />
      <div className="grid grid-cols-4 gap-2">
        {buttons.map((btn, index) => (
          <CalculatorButton
            key={index}
            label={btn.label}
            onClick={btn.action}
            type={btn.type}
          />
        ))}
      </div>
    </div>
  );
};

export default Calculator;