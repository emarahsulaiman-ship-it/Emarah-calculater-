interface ResultCardProps {
  label: string;
  value: string;
  unit: string;
  color: "amber" | "sky" | "emerald" | "rose" | "violet" | "fuchsia" | "cyan" | "teal";
  highlight?: boolean;
  isIQD?: boolean;
}

const ResultCard = ({ label, value, unit, color, highlight, isIQD }: ResultCardProps) => {
  const colorClasses = {
    amber: "bg-amber-500/10 border-amber-500/20",
    sky: "bg-sky-500/10 border-sky-500/20",
    emerald: "bg-emerald-500/10 border-emerald-500/20",
    rose: "bg-rose-500/10 border-rose-500/20",
    violet: "bg-violet-500/10 border-violet-500/20",
    fuchsia: "bg-fuchsia-500/10 border-fuchsia-500/20",
    cyan: "bg-cyan-500/10 border-cyan-500/20",
    teal: "bg-teal-500/10 border-teal-500/20",
  };

  const textClasses = {
    amber: "text-amber-400",
    sky: "text-sky-400",
    emerald: "text-emerald-400",
    rose: "text-rose-400",
    violet: "text-violet-400",
    fuchsia: "text-fuchsia-400",
    cyan: "text-cyan-400",
    teal: "text-teal-400",
  };

  return (
    <div className={`flex items-center justify-between p-4 rounded-xl border ${colorClasses[color]} ${highlight ? 'ring-1 ring-offset-1 ring-offset-slate-800' : ''}`}>
      <span className="text-sm text-slate-300">{label}</span>
      <div className="flex items-baseline gap-2">
        <span className={`text-xl font-bold ${textClasses[color]}`}>
          {isIQD && value !== "0.00" ? value : value}
        </span>
        <span className="text-xs text-slate-500">{unit}</span>
      </div>
    </div>
  );
};

export default ResultCard;