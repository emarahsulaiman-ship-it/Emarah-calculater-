import { useState } from "react";
import InputField from "./InputField";
import ResultCard from "./ResultCard";
import { calculateFabricCost, calculateBags } from "../utils/calculations";
import { CalculationRecord } from "../types/calculator";

interface FabricCalculatorProps {
  onCalculate: (record: CalculationRecord) => void;
}

const FabricCalculator = ({ onCalculate }: FabricCalculatorProps) => {
  const [tonPrice, setTonPrice] = useState<string>("2000");
  const [fabricWidth, setFabricWidth] = useState<string>("50");
  const [gramWeight, setGramWeight] = useState<string>("63");
  const [transportCost, setTransportCost] = useState<string>("0");
  const [includeTransport, setIncludeTransport] = useState<boolean>(false);
  
  // سعر صرف الدولار للدينار العراقي
  const [exchangeRate, setExchangeRate] = useState<string>("1320");
  const [showExchangeRate, setShowExchangeRate] = useState<boolean>(false);
  
  // حساب الأكياس
  const [showBagsCalculation, setShowBagsCalculation] = useState<boolean>(false);
  const [bagLength, setBagLength] = useState<string>("50");
  const [bagsResult, setBagsResult] = useState<{
    bagWeight: number;
    bagsInTon: number;
    bagsPrice: number;
    bagsPriceIQD: number;
  } | null>(null);
  
  const [results, setResults] = useState<{
    meterWeight: number;
    metersInTon: number;
    meterPrice: number;
    totalCost: number;
    meterPriceIQD: number;
    totalCostIQD: number;
  } | null>(null);

  const handleCalculate = () => {
    const ton = parseFloat(tonPrice) || 0;
    const width = parseFloat(fabricWidth) || 0;
    const gram = parseFloat(gramWeight) || 0;
    const transport = includeTransport ? (parseFloat(transportCost) || 0) : 0;
    const rate = parseFloat(exchangeRate) || 1320;
    const bagLen = parseFloat(bagLength) || 50;

    if (ton <= 0 || width <= 0 || gram <= 0) {
      return;
    }

    const calculation = calculateFabricCost(ton, width, gram, transport);
    
    const finalResults = {
      ...calculation,
      meterPriceIQD: calculation.meterPrice * rate,
      totalCostIQD: calculation.totalCost * rate,
    };
    
    setResults(finalResults);

    // حساب الأكياس إذا كان مفعلاً
    if (showBagsCalculation) {
      const bagsCalc = calculateBags(calculation.meterWeight, ton, bagLen, rate);
      setBagsResult(bagsCalc);
    }

    onCalculate({
      id: Date.now(),
      date: new Date().toLocaleDateString("ar-SA"),
      inputs: {
        tonPrice: ton,
        fabricWidth: width,
        gramWeight: gram,
        transportCost: transport,
        exchangeRate: rate,
        bagLength: bagLen,
      },
      results: finalResults,
      bagsResult: showBagsCalculation ? bagsResult : undefined,
    });
  };

  const handleReset = () => {
    setTonPrice("2000");
    setFabricWidth("50");
    setGramWeight("63");
    setTransportCost("0");
    setIncludeTransport(false);
    setExchangeRate("1320");
    setShowExchangeRate(false);
    setShowBagsCalculation(false);
    setBagLength("50");
    setResults(null);
    setBagsResult(null);
  };

  return (
    <div className="space-y-4">
      {/* بطاقة الإدخال */}
      <div className="bg-slate-800/80 backdrop-blur-sm rounded-3xl p-5 shadow-xl border border-slate-700/50">
        <h2 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
          <span className="w-8 h-8 bg-amber-500/20 rounded-xl flex items-center justify-center">
            <svg className="w-4 h-4 text-amber-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
            </svg>
          </span>
          بيانات القماش
        </h2>

        <div className="space-y-4">
          <InputField
            label="سعر الطن"
            value={tonPrice}
            onChange={setTonPrice}
            unit="دولار"
            icon="$"
            placeholder="أدخل سعر الطن"
          />

          <InputField
            label="عرض القماش"
            value={fabricWidth}
            onChange={setFabricWidth}
            unit="سم"
            icon="↔"
            placeholder="أدخل عرض القماش"
          />

          <InputField
            label="وزن المتر المربع"
            value={gramWeight}
            onChange={setGramWeight}
            unit="غرام"
            icon="⚖"
            placeholder="أدخل الوزن بالغرام"
          />
        </div>
      </div>

      {/* بطاقة حساب الأكياس */}
      <div className="bg-slate-800/80 backdrop-blur-sm rounded-3xl p-5 shadow-xl border border-slate-700/50">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-white flex items-center gap-2">
            <span className="w-8 h-8 bg-cyan-500/20 rounded-xl flex items-center justify-center">
              <svg className="w-4 h-4 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
              </svg>
            </span>
            حساب عدد الأكياس
          </h2>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={showBagsCalculation}
              onChange={(e) => setShowBagsCalculation(e.target.checked)}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-slate-600 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:right-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-cyan-500"></div>
          </label>
        </div>

        {showBagsCalculation && (
          <div className="space-y-3">
            <InputField
              label="طول الكيس"
              value={bagLength}
              onChange={setBagLength}
              unit="متر"
              icon="📏"
              placeholder="أدخل طول الكيس"
            />
            <div className="flex items-center gap-2 text-xs text-slate-400 bg-slate-700/30 rounded-xl p-3">
              <svg className="w-4 h-4 text-cyan-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <span>سيتم حساب عدد الأكياس في الطن الواحد</span>
            </div>
          </div>
        )}
      </div>

      {/* بطاقة المصاريف */}
      <div className="bg-slate-800/80 backdrop-blur-sm rounded-3xl p-5 shadow-xl border border-slate-700/50">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-white flex items-center gap-2">
            <span className="w-8 h-8 bg-rose-500/20 rounded-xl flex items-center justify-center">
              <svg className="w-4 h-4 text-rose-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" />
              </svg>
            </span>
            مصاريف النقل
          </h2>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={includeTransport}
              onChange={(e) => setIncludeTransport(e.target.checked)}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-slate-600 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:right-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-rose-500"></div>
          </label>
        </div>

        {includeTransport && (
          <InputField
            label="تكلفة النقل"
            value={transportCost}
            onChange={setTransportCost}
            unit="دولار"
            icon="🚚"
            placeholder="أدخل تكلفة النقل"
          />
        )}
      </div>

      {/* بطاقة سعر الصرف */}
      <div className="bg-slate-800/80 backdrop-blur-sm rounded-3xl p-5 shadow-xl border border-slate-700/50">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-white flex items-center gap-2">
            <span className="w-8 h-8 bg-violet-500/20 rounded-xl flex items-center justify-center">
              <svg className="w-4 h-4 text-violet-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
              </svg>
            </span>
            تحويل الدينار العراقي
          </h2>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={showExchangeRate}
              onChange={(e) => setShowExchangeRate(e.target.checked)}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-slate-600 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:right-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-violet-500"></div>
          </label>
        </div>

        {showExchangeRate && (
          <div className="space-y-3">
            <InputField
              label="سعر صرف الدولار"
              value={exchangeRate}
              onChange={setExchangeRate}
              unit="دينار عراقي"
              icon="💰"
              placeholder="أدخل سعر الصرف"
            />
            <div className="flex items-center gap-2 text-xs text-slate-400 bg-slate-700/30 rounded-xl p-3">
              <svg className="w-4 h-4 text-violet-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <span>كل دولار واحد = {exchangeRate || "0"} دينار عراقي</span>
            </div>
          </div>
        )}
      </div>

      {/* أزرار التحكم */}
      <div className="flex gap-3">
        <button
          onClick={handleCalculate}
          className="flex-1 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 active:from-emerald-600 active:to-teal-600 text-white font-semibold py-4 rounded-2xl transition-all duration-200 shadow-lg shadow-emerald-500/25 flex items-center justify-center gap-2"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
          </svg>
          احسب
        </button>
        <button
          onClick={handleReset}
          className="bg-slate-700 hover:bg-slate-600 active:bg-slate-500 text-white font-semibold py-4 px-6 rounded-2xl transition-all duration-200"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.001 8.001 0 01-15.357-2m15.357 2H15" />
          </svg>
        </button>
      </div>

      {/* النتائج */}
      {results && (
        <div className="bg-slate-800/80 backdrop-blur-sm rounded-3xl p-5 shadow-xl border border-emerald-500/30">
          <h2 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <span className="w-8 h-8 bg-emerald-500/20 rounded-xl flex items-center justify-center">
              <svg className="w-4 h-4 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </span>
            نتائج الحساب
          </h2>

          <div className="space-y-3">
            <ResultCard
              label="وزن المتر الطولي"
              value={results.meterWeight.toFixed(2)}
              unit="غرام"
              color="amber"
            />
            <ResultCard
              label="عدد الأمتار في الطن"
              value={results.metersInTon.toFixed(2)}
              unit="متر"
              color="sky"
            />
            
            {/* قسم الأسعار بالدولار */}
            <div className="pt-2 border-t border-slate-700/50">
              <p className="text-xs text-slate-500 mb-2">الأسعار بالدولار الأمريكي</p>
              <ResultCard
                label="سعر المتر"
                value={results.meterPrice.toFixed(2)}
                unit="دولار"
                color="emerald"
                highlight
              />
              {includeTransport && (
                <ResultCard
                  label="الكلفة الإجمالية للمتر"
                  value={results.totalCost.toFixed(2)}
                  unit="دولار"
                  color="rose"
                  highlight
                />
              )}
            </div>

            {/* قسم الأسعار بالدينار العراقي */}
            {showExchangeRate && (
              <div className="pt-2 border-t border-slate-700/50">
                <p className="text-xs text-slate-500 mb-2">الأسعار بالدينار العراقي</p>
                <ResultCard
                  label="سعر المتر"
                  value={results.meterPriceIQD.toLocaleString('en-US')}
                  unit="دينار"
                  color="violet"
                  highlight
                  isIQD
                />
                {includeTransport && (
                  <ResultCard
                    label="الكلفة الإجمالية للمتر"
                    value={results.totalCostIQD.toLocaleString('en-US')}
                    unit="دينار"
                    color="fuchsia"
                    highlight
                    isIQD
                  />
                )}
              </div>
            )}

            {/* قسم حساب الأكياس */}
            {showBagsCalculation && bagsResult && (
              <div className="pt-2 border-t border-slate-700/50">
                <p className="text-xs text-slate-500 mb-2 flex items-center gap-1">
                  <svg className="w-3 h-3 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
                  </svg>
                  حساب الأكياس (طول {bagLength} متر)
                </p>
                <ResultCard
                  label="وزن الكيس الواحد"
                  value={bagsResult.bagWeight.toFixed(2)}
                  unit="غرام"
                  color="cyan"
                />
                <ResultCard
                  label="عدد الأكياس في الطن"
                  value={bagsResult.bagsInTon.toFixed(0)}
                  unit="كيس"
                  color="teal"
                  highlight
                />
                <ResultCard
                  label="سعر الكيس الواحد"
                  value={bagsResult.bagsPrice.toFixed(2)}
                  unit="دولار"
                  color="emerald"
                  highlight
                />
                {showExchangeRate && (
                  <ResultCard
                    label="سعر الكيس بالدينار"
                    value={bagsResult.bagsPriceIQD.toLocaleString('en-US')}
                    unit="دينار"
                    color="violet"
                    highlight
                    isIQD
                  />
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* شرح طريقة الحساب */}
      <div className="bg-slate-800/50 rounded-2xl p-4 border border-slate-700/30">
        <h3 className="text-sm font-medium text-slate-300 mb-2">طريقة الحساب:</h3>
        <div className="text-xs text-slate-400 space-y-1" dir="ltr">
          <p>• وزن المتر = (العرض × 1 × 2 × الوزن/م²) ÷ 100</p>
          <p>• عدد الأمتار = 1,000,000 ÷ وزن المتر</p>
          <p>• سعر المتر = سعر الطن ÷ عدد الأمتار</p>
          <p>• السعر بالدينار = سعر المتر × سعر الصرف</p>
          {showBagsCalculation && (
            <>
              <p className="text-cyan-400">• وزن الكيس = وزن المتر × طول الكيس</p>
              <p className="text-cyan-400">• عدد الأكياس = 1,000,000 ÷ وزن الكيس</p>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default FabricCalculator;