interface InputFieldProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
  unit: string;
  icon: string;
  placeholder: string;
}

const InputField = ({ label, value, onChange, unit, icon, placeholder }: InputFieldProps) => {
  return (
    <div className="space-y-2">
      <label className="text-sm text-slate-400 font-medium">{label}</label>
      <div className="relative">
        <span className="absolute right-4 top-1/2 -translate-y-1/2 text-lg">{icon}</span>
        <input
          type="number"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          className="w-full bg-slate-700/50 border border-slate-600/50 rounded-xl py-3 pr-11 pl-16 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500/50 focus:ring-2 focus:ring-emerald-500/20 transition-all"
          dir="ltr"
        />
        <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 text-sm">{unit}</span>
      </div>
    </div>
  );
};

export default InputField;