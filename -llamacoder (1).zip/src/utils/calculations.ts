export const calculateFabricCost = (
  tonPrice: number,
  fabricWidth: number,
  gramWeight: number,
  transportCost: number
) => {
  // حساب وزن المتر الطولي
  // الوزن = (العرض بالمتر × 1 متر × 2 طبقتين × الوزن بالغرام) ÷ 100
  const widthInMeters = fabricWidth / 100;
  const meterWeight = (widthInMeters * 1 * 2 * gramWeight);

  // عدد الأمتار في الطن
  // الطن = 1,000,000 غرام
  const metersInTon = 1000000 / meterWeight;

  // سعر المتر
  const meterPrice = tonPrice / metersInTon;

  // الكلفة الإجمالية مع النقل
  const totalCost = meterPrice + (transportCost / metersInTon);

  return {
    meterWeight,
    metersInTon,
    meterPrice,
    totalCost,
  };
};

export const calculateBags = (
  meterWeight: number,
  tonPrice: number,
  bagLength: number,
  exchangeRate: number
) => {
  // وزن الكيس = وزن المتر الطولي × طول الكيس
  const bagWeight = meterWeight * bagLength;

  // عدد الأكياس في الطن
  const bagsInTon = 1000000 / bagWeight;

  // سعر الكيس الواحد بالدولار
  const bagsPrice = tonPrice / bagsInTon;

  // سعر الكيس بالدينار العراقي
  const bagsPriceIQD = bagsPrice * exchangeRate;

  return {
    bagWeight,
    bagsInTon,
    bagsPrice,
    bagsPriceIQD,
  };
};