export const calculate = (a: number, b: number, operator: string): number => {
  switch (operator) {
    case "+":
      return a + b;
    case "-":
      return a - b;
    case "×":
      return a * b;
    case "÷":
      return b !== 0 ? a / b : 0;
    default:
      return b;
  }
};

export const formatNumber = (num: number): string => {
  if (Number.isInteger(num)) {
    return num.toLocaleString("en-US");
  }
  return parseFloat(num.toFixed(8)).toLocaleString("en-US");
};